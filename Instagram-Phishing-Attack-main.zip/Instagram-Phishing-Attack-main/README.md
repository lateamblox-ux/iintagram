# Instagram Phishing Attack

This is a basic phishing attack tool designed to simulate an Instagram login page. When a victim enters their credentials, the data along with their IP address will be saved in a `.txt` file.

**Disclaimer: This tool was created strictly for educational purposes. Do not misuse it for illegal activities!**

### Features

- Fake Instagram login page to capture credentials
- Logs any data entered by the victim (username, password)
- Captures and stores the victim's IP address
- Stores the collected data in a `.txt` file for review

### Requirements

- Python 3.x
- A web server to host the fake login page

### Installation

1. Clone or download this repository.
2. Set up a web server (e.g., using XAMPP, WAMP, or Python's built-in server).
3. Place the phishing page files in the appropriate directory.

### Usage

1. Host the fake Instagram login page on your web server.
2. Share the link to the victim (make sure the page looks convincing).
3. Any data entered by the victim will be stored in a `.txt` file along with their IP address.
4. Review the data stored in the `.txt` file to see the captured credentials.

### Disclaimer

- **This tool is for educational purposes only!**  
  - It is meant to teach the importance of cybersecurity and how phishing attacks work, so that individuals and organizations can better protect themselves.
  - Unauthorized use of this tool for illegal purposes is strictly prohibited and can result in severe legal consequences.

### Notes

- Ensure that the victim is aware of the educational purpose, or use this tool in a legal and controlled environment (e.g., cybersecurity training exercises).
- Always respect privacy and legal boundaries.
